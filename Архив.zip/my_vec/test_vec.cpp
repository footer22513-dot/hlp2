#include "vec.h"
#include "../models/user/user.h"
#include "../models/employee/employee.h"
#include "../models/supplier/supplier.h"
#include "../models/worker/worker.h"
#include <iostream>

int main() {
  user_vec vec;

  // Добавляем разные типы пользователей
  vec.push_back(new employee("Alice", "Smith", 30, "alice", "pass123", "manager"));
  vec.push_back(new supplier("Bob", "Johnson", 45, "bob", "pass456", "Electronics"));
  vec.push_back(new worker("Charlie", "Brown", 25, "charlie", "pass789", "senior"));

  std::cout << "Size: " << vec.size() << std::endl;

  for (size_t i = 0; i < vec.size(); i++) {
    std::cout << "vec[" << i << "]: ";
    vec[i]->show_info();
  }

  std::cout << "\nIterators: " << std::endl;
  for (auto it = vec.begin(); it != vec.end(); ++it) {
    (*it)->show_info();
  }

  std::cout << "\nDo work:" << std::endl;
  for (size_t i = 0; i < vec.size(); i++) {
    vec[i]->do_work();
  }

  return 0;
}
