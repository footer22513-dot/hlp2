#include "account_vec.h"

account_iterator::account_iterator(Account *ptr) : m_ptr(ptr) {}

Account &account_iterator::operator*() const { return *m_ptr; }
Account *account_iterator::operator->() const { return m_ptr; }

account_iterator &account_iterator::operator++() {
  ++m_ptr;
  return *this;
}

account_iterator account_iterator::operator++(int) {
  account_iterator tmp = *this;
  ++m_ptr;
  return tmp;
}

bool account_iterator::operator==(const account_iterator &other) const {
  return m_ptr == other.m_ptr;
}

bool account_iterator::operator!=(const account_iterator &other) const {
  return m_ptr != other.m_ptr;
}

account_vec::account_vec() : m_data(nullptr), m_size(0), m_capacity(0) {}

account_vec::~account_vec() { delete[] m_data; }

void account_vec::resize() {
  m_capacity = (m_capacity == 0) ? 1 : m_capacity * 2;
  Account *newData = new Account[m_capacity];
  for (int i = 0; i < m_size; i++)
    newData[i] = m_data[i];
  delete[] m_data;
  m_data = newData;
}

size_t account_vec::size() const { return m_size; }

bool account_vec::empty() const { return m_size == 0; }

void account_vec::push_back(const Account &value) {
  if (m_size >= m_capacity) {
    resize();
  }
  m_data[m_size++] = value;
}

Account &account_vec::operator[](size_t i) { return m_data[i]; }

const Account &account_vec::operator[](size_t i) const { return m_data[i]; }

account_iterator account_vec::begin() { return account_iterator(m_data); }

account_iterator account_vec::end() { return account_iterator(m_data + m_size); }
