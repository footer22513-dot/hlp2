#pragma once
#include <cstddef>

struct user;

class user_iterator {
private:
  user **m_ptr;

public:
  user_iterator(user **ptr);

  user *operator*() const;

  user_iterator &operator++();
  user_iterator operator++(int);

  bool operator==(const user_iterator &other) const;
  bool operator!=(const user_iterator &other) const;
};

class user_vec {
private:
  user **m_data;
  int m_size;
  int m_capacity;

  void resize();

public:
  user_vec();
  ~user_vec();

  user_vec(const user_vec &) = delete;
  user_vec &operator=(const user_vec &) = delete;

  size_t size() const;
  bool empty() const;

  void push_back(user *value);

  user *operator[](size_t i);
  const user *operator[](size_t i) const;

  user_iterator begin();
  user_iterator end();
};
