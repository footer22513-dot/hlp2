#include "vec.h"
#include "../models/user/user.h"

user_iterator::user_iterator(user **ptr) : m_ptr(ptr) {}

user *user_iterator::operator*() const { return *m_ptr; }

user_iterator &user_iterator::operator++() {
  ++m_ptr;
  return *this;
}

user_iterator user_iterator::operator++(int) {
  user_iterator tmp = *this;
  ++m_ptr;
  return tmp;
}

bool user_iterator::operator==(const user_iterator &other) const {
  return m_ptr == other.m_ptr;
}

bool user_iterator::operator!=(const user_iterator &other) const {
  return m_ptr != other.m_ptr;
}

user_vec::user_vec() : m_data(nullptr), m_size(0), m_capacity(0) {}

user_vec::~user_vec() {
  for (int i = 0; i < m_size; i++)
    delete m_data[i];
  delete[] m_data;
}

void user_vec::resize() {
  m_capacity = (m_capacity == 0) ? 1 : m_capacity * 2;
  user **newData = new user *[m_capacity];
  for (int i = 0; i < m_size; i++)
    newData[i] = m_data[i];
  delete[] m_data;
  m_data = newData;
}

size_t user_vec::size() const { return m_size; }

bool user_vec::empty() const { return m_size == 0; }

void user_vec::push_back(user *value) {
  if (m_size >= m_capacity) {
    resize();
  }
  m_data[m_size++] = value;
}

user *user_vec::operator[](size_t i) { return m_data[i]; }

const user *user_vec::operator[](size_t i) const { return m_data[i]; }

user_iterator user_vec::begin() { return user_iterator(m_data); }

user_iterator user_vec::end() { return user_iterator(m_data + m_size); }
