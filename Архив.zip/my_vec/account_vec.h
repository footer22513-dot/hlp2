#pragma once
#include <cstddef>
#include <string>

struct Account {
  std::string login;
  std::string password;
  std::string role;
};

class account_iterator {
private:
  Account *m_ptr;

public:
  account_iterator(Account *ptr);

  Account &operator*() const;
  Account *operator->() const;

  account_iterator &operator++();
  account_iterator operator++(int);

  bool operator==(const account_iterator &other) const;
  bool operator!=(const account_iterator &other) const;
};

class account_vec {
private:
  Account *m_data;
  int m_size;
  int m_capacity;

  void resize();

public:
  account_vec();
  ~account_vec();

  account_vec(const account_vec &) = delete;
  account_vec &operator=(const account_vec &) = delete;

  size_t size() const;
  bool empty() const;

  void push_back(const Account &value);

  Account &operator[](size_t i);
  const Account &operator[](size_t i) const;

  account_iterator begin();
  account_iterator end();
};
